# react-native-video-test
This is not library repo - library repo was move here https://github.com/TheWidlarzGroup/react-native-video

This sample app is not maintained anymore, if you want to test react-native-video, you can use sample app included in react-native-video repository.

It is available here: https://github.com/TheWidlarzGroup/react-native-video/tree/master/examples/basic


